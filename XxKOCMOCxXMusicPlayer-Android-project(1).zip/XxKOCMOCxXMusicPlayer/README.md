# XxKOCMOCxX Music Player
Android music player with local audio selection, playback, previous/next, seek and track list.
## Build APK
GitHub Actions builds a debug APK on push to main/master or manually via Actions > Build Android APK > Run workflow.
