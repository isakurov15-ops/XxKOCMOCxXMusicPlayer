package com.xxkocmoc.musicplayer;
import android.app.Activity; import android.content.Intent; import android.net.Uri; import android.os.Bundle; import android.webkit.ValueCallback; import android.webkit.WebChromeClient; import android.webkit.WebView; import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 private WebView webView; private ValueCallback<Uri[]> fileCallback; private static final int PICK=101;
 @Override public void onCreate(Bundle b){super.onCreate(b); webView=new WebView(this); webView.getSettings().setJavaScriptEnabled(true); webView.getSettings().setDomStorageEnabled(true); webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient(){ public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){ if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;try{startActivityForResult(p.createIntent(),PICK);}catch(Exception e){fileCallback=null;cb.onReceiveValue(null);return false;}return true;}});setContentView(webView);webView.loadUrl("file:///android_asset/index.html"); }
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&fileCallback!=null){Uri[] u=(c==RESULT_OK&&d!=null)?WebChromeClient.FileChooserParams.parseResult(c,d):null;fileCallback.onReceiveValue(u);fileCallback=null;}}
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
